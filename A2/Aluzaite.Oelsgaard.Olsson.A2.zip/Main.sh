#!/bin/bash
cd src
python II.1.1-2.py
python II.2.1.py
python II.2.2.py


